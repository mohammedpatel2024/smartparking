import cv2
import numpy as np
import time
import requests

# ===================== CONFIGURATION =====================
VIDEO_PATH = r"C:/Users/DELL/Downloads/parking-spot-detector-main/parking-spot-detector-main/video/CarPark.mp4"
RECT_WIDTH, RECT_HEIGHT = 100, 33
PIXEL_THRESHOLD = 30
TEXT_COLOR = (200, 255, 255)
UPDATE_INTERVAL = 0.1  # seconds

# Telegram Bot Settings
BOT_TOKEN = "7171856301:AAF4nPDs3iCNnRybdtLBAzWZexz"#put your token
CHAT_ID = "176"#put your chat id 

# Overlay image
overlay_img = cv2.imread(r"C:\Users\DELL\Downloads\parking-spot-detector-main\generation-b2a10189-454c-4fb8-be69-d88cdb89294e.png")
overlay_img = cv2.resize(overlay_img, (100, 100))  # resize

# Parking slot coordinates
PARKING_SLOTS = [
    (402, 239), (753, 377), (55, 100), (56, 146), (51, 241), (53, 290), (51, 192),
    (405, 189), (402, 138), (405, 90), (514, 92), (511, 139), (514, 187), (512, 236),
    (163, 99), (164, 147), (158, 194), (159, 243), (161, 290), (55, 337), (162, 339),
    (160, 388), (162, 429), (52, 431), (53, 479), (163, 479), (168, 525), (165, 576),
    (165, 620), (56, 623), (51, 573), (52, 527), (402, 289), (402, 338), (404, 382),
    (405, 427), (405, 526), (403, 569), (406, 619), (512, 524), (512, 568), (513, 620),
    (511, 426), (511, 380), (513, 329), (511, 284), (751, 88), (751, 136), (750, 188),
    (753, 232), (753, 276), (751, 327), (757, 427), (753, 472), (757, 518), (760, 573),
    (760, 616), (901, 620), (901, 576), (892, 141), (892, 190), (893, 235), (894, 284),
    (897, 330), (898, 375), (901, 424), (903, 474), (899, 522), (46, 385)
]

# ===================== FUNCTIONS =====================
def send_telegram_alert(message):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    data = {"chat_id": CHAT_ID, "text": message}
    try:
        requests.post(url, data=data)
    except:
        print("Failed to send Telegram message.")

def preprocess_frame(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    _, binary = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contour_image = np.zeros_like(frame)
    cv2.drawContours(contour_image, contours, -1, (255, 255, 255), 2)
    return contour_image

def add_overlay(frame, overlay_img):
    h, w, _ = frame.shape
    oh, ow, _ = overlay_img.shape
    x_offset = w - ow - 10
    y_offset = 10
    frame[y_offset:y_offset+oh, x_offset:x_offset+ow] = overlay_img
    return frame

def draw_parking_slots(frame, processed_frame, prev_free_slots, last_update_time):
    free_slots = 0
    font = cv2.FONT_HERSHEY_SIMPLEX

    for x, y in PARKING_SLOTS:
        x1, y1 = x + 10, y + 4
        x2, y2 = x + RECT_WIDTH - 11, y + RECT_HEIGHT
        crop = processed_frame[y1:y2, x1:x2]
        gray_crop = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        non_zero_count = cv2.countNonZero(gray_crop)

        if non_zero_count < PIXEL_THRESHOLD:
            color, label = (0, 255, 0), "FREE"
            free_slots += 1
        else:
            color, label = (0, 0, 255), "STOP"

        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        cv2.putText(frame, label, (x1, y1 - 5), font, 0.5, color, 2)

    occupied_slots = len(PARKING_SLOTS) - free_slots
    current_time = time.time()

    if current_time - last_update_time >= UPDATE_INTERVAL:
        cv2.putText(frame, f"Free: {free_slots} | Occupied: {occupied_slots}", (10, 30), font, 1, TEXT_COLOR, 2)
        last_update_time = current_time

        # Send Telegram alert only if new free slots appear
        if free_slots > prev_free_slots:
            message = f"🚗 Parking Update 🚗\nFree Slots: {free_slots}\nOccupied Slots: {occupied_slots}"
            send_telegram_alert(message)

        prev_free_slots = free_slots
    else:
        cv2.putText(frame, f"Free: {prev_free_slots} | Occupied: {len(PARKING_SLOTS) - prev_free_slots}", (10, 30), font, 1, TEXT_COLOR, 2)

    return frame, prev_free_slots, last_update_time

def add_legend(image):
    legend_x, legend_y = 10, 60
    box_size, spacing = 20, 10
    font = cv2.FONT_HERSHEY_SIMPLEX

    cv2.rectangle(image, (legend_x, legend_y), (legend_x+box_size, legend_y+box_size), (0, 255, 0), -1)
    cv2.putText(image, "Free Space", (legend_x+box_size+10, legend_y+box_size-5), font, 0.6, (255,255,255), 2)
    legend_y += box_size + spacing
    cv2.rectangle(image, (legend_x, legend_y), (legend_x+box_size, legend_y+box_size), (0, 0, 255), -1)
    cv2.putText(image, "Stop", (legend_x+box_size+10, legend_y+box_size-5), font, 0.6, (255,255,255), 2)

    return image

# ===================== MAIN LOOP =====================
cap = cv2.VideoCapture(VIDEO_PATH)
prev_free_slots = 0
last_update_time = time.time()

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    processed_frame = preprocess_frame(frame)
    output_frame, prev_free_slots, last_update_time = draw_parking_slots(
        frame, processed_frame, prev_free_slots, last_update_time
    )

    # Add overlay image
    output_frame = add_overlay(output_frame, overlay_img)

    # Add legend
    output_frame = add_legend(output_frame)

    cv2.imshow("Parking Spot Detector", output_frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
